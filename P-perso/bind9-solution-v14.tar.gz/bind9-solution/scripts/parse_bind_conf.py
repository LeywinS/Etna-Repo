#!/usr/bin/env python3
"""Extrait les views, ACL et zones (avec leur chemin réel) de fichiers
named.conf*, pour importer un serveur BIND sans rien y déplacer.

Usage: parse_bind_conf.py <dossier_conf> <serveur> <dossier_sortie>
                          [conf_resolue]

Si <conf_resolue> est fourni (sortie de `named-checkconf -p`), c'est
elle qui sert à l'analyse : tous les include sont déjà suivis par BIND,
à tous les niveaux. Sinon on se replie sur la concaténation des
fichiers named.conf* (des zones incluses depuis un fichier au nom non
standard peuvent alors manquer).
Produit: <sortie>/_parsed.json          (view, zone, chemin distant)
         <sortie>/host_vars.yml.draft   (brouillon host_vars/<serveur>.yml)
"""
import json
import os
import re
import sys


def strip_comments(text):
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.S)
    out = []
    for line in text.splitlines():
        line = re.sub(r'//.*$', '', line)
        line = re.sub(r'(?<!\S)#.*$', '', line)
        out.append(line)
    return '\n'.join(out)


def find_blocks(text, keyword):
    """Retourne [(nom, contenu)] pour chaque bloc `keyword "nom" { ... }`,
    en équilibrant les accolades (blocs imbriqués supportés)."""
    blocks = []
    for m in re.finditer(keyword + r'\s+"?([^"\s{]+)"?\s*(?:\w+\s+)?\{', text):
        start = text.index('{', m.end() - 1)
        depth, i = 0, start
        while i < len(text):
            if text[i] == '{':
                depth += 1
            elif text[i] == '}':
                depth -= 1
                if depth == 0:
                    break
            i += 1
        blocks.append((m.group(1), text[start + 1:i]))
    return blocks


def zone_layout(zones):
    """Déduit zone_dir (dossier majoritaire) et les exceptions
    zone_paths : toute zone dont le chemin réel n'est pas
    <zone_dir>/<nom de la zone> (autre dossier, ou nom de fichier
    différent comme db.example.com)."""
    if not zones:
        return {}
    dirs = [os.path.dirname(p) for p in zones.values()]
    # Dossier le plus fréquent ; à égalité, le premier par ordre
    # alphabétique — le résultat doit être identique à chaque import.
    zone_dir = sorted(set(dirs), key=lambda d: (-dirs.count(d), d))[0]
    exceptions = {z: p for z, p in zones.items()
                  if p != os.path.join(zone_dir, z)}
    layout = {'zone_dir': zone_dir}
    if exceptions:
        layout['zone_paths'] = exceptions
    return layout


def main():
    conf_dir, server, out_dir = sys.argv[1], sys.argv[2], sys.argv[3]
    resolved = sys.argv[4] if len(sys.argv) > 4 else ''

    if resolved and os.path.exists(resolved):
        with open(resolved, errors='replace') as fh:
            text = fh.read()
        source = 'named-checkconf -p (tous les include résolus)'
    else:
        text = ''
        for name in sorted(os.listdir(conf_dir)):
            if name.startswith('named.conf'):
                with open(os.path.join(conf_dir, name), errors='replace') as fh:
                    text += '\n' + fh.read()
        source = 'fichiers named.conf* (include externes NON résolus)'
    text = strip_comments(text)

    # ACL : nom -> liste de réseaux
    acls = {}
    for name, body in find_blocks(text, 'acl'):
        acls[name.strip('"')] = [e.strip().strip('"')
                                 for e in body.split(';') if e.strip()]

    managed = {'named.conf', 'named.conf.options', 'named.conf.logging',
               'named.conf.acl', 'named.conf.views', 'named.conf.local'}
    extra_includes = []
    for name in sorted(os.listdir(conf_dir)):
        if name not in managed:
            continue
        with open(os.path.join(conf_dir, name), errors='replace') as fh:
            for m in re.finditer(r'include\s+"([^"]+)"', strip_comments(fh.read())):
                if os.path.basename(m.group(1)) not in managed:
                    extra_includes.append(m.group(1))
    extra_includes = sorted(set(extra_includes))
    # Un include dont le fichier contient des view/zone/acl est
    # désormais géré par l'outil : le réémettre créerait des doublons.
    # On ne peut pas toujours l'inspecter (fichier hors /etc/bind non
    # rapatrié) : dans le doute on le commente et on alerte.
    safe_includes, risky_includes = [], []
    for inc in extra_includes:
        local = os.path.join(conf_dir, os.path.basename(inc))
        if os.path.exists(local):
            with open(local, errors='replace') as fh:
                body = strip_comments(fh.read())
            if re.search(r'\b(view|zone|acl)\s+"?[\w.\-]+"?\s*\{', body):
                risky_includes.append(inc)
            else:
                safe_includes.append(inc)
        else:
            risky_includes.append(inc)

    views, parsed, skipped = [], [], []
    secondaries = {}
    for vname, vbody in find_blocks(text, 'view'):
        vname = vname.strip('"')
        m = re.search(r'match-clients\s*\{(.*?)\}', vbody, flags=re.S)
        raw = [e.strip().strip('"') for e in m.group(1).split(';')
               if e.strip()] if m else ['any']
        clients = []
        for entry in raw:                      # résout les noms d'ACL
            clients.extend(acls.get(entry, [entry]))

        zones = {}
        for zname, zbody in find_blocks(vbody, 'zone'):
            zname = zname.strip('"')
            tm = re.search(r'type\s+(\w+)', zbody)
            ztype = tm.group(1) if tm else 'primary'
            if ztype in ('secondary', 'slave'):
                fm = re.search(r'file\s+"([^"]+)"', zbody)
                pm = re.search(r'(?:primaries|masters)\s*\{(.*?)\}', zbody, flags=re.S)
                secondaries.setdefault(vname, []).append({
                    'name': zname,
                    'primaries': [e.strip() for e in pm.group(1).split(';') if e.strip()] if pm else [],
                    'file': fm.group(1) if fm else ''})
                continue
            if ztype not in ('primary', 'master'):
                skipped.append({'view': vname, 'zone': zname, 'type': ztype})
                continue
            fm = re.search(r'file\s+"([^"]+)"', zbody)
            if not fm:
                skipped.append({'view': vname, 'zone': zname, 'type': ztype + ' (no file)'})
                continue
            zones[zname] = fm.group(1)
            parsed.append({'view': vname, 'zone': zname, 'path': fm.group(1)})

        view = {'name': vname, 'match_clients': clients}
        view.update(zone_layout(zones))
        if secondaries.get(vname):
            view['secondary_zones'] = secondaries[vname]
        views.append(view)

    # Mode sans views : zones déclarées globalement. BIND interdit de
    # mélanger les deux, donc c'est l'un OU l'autre.
    use_views = bool(views)
    if not use_views:
        zones = {}
        for zname, zbody in find_blocks(text, 'zone'):
            zname = zname.strip('"')
            tm = re.search(r'type\s+(\w+)', zbody)
            ztype = tm.group(1) if tm else 'primary'
            fm = re.search(r'file\s+"([^"]+)"', zbody)
            if ztype in ('secondary', 'slave'):
                pm = re.search(r'(?:primaries|masters)\s*\{(.*?)\}', zbody, flags=re.S)
                secondaries.setdefault('_global', []).append({
                    'name': zname,
                    'primaries': [e.strip() for e in pm.group(1).split(';') if e.strip()] if pm else [],
                    'file': fm.group(1) if fm else ''})
                continue
            if ztype not in ('primary', 'master') or not fm:
                skipped.append({'view': '_global', 'zone': zname,
                                'type': ztype if fm else ztype + ' (no file)'})
                continue
            zones[zname] = fm.group(1)
            parsed.append({'view': '_global', 'zone': zname, 'path': fm.group(1)})
        if zones:
            view = {'name': '_global', 'match_clients': ['any']}
            view.update(zone_layout(zones))
            if secondaries.get('_global'):
                view['secondary_zones'] = secondaries['_global']
            views.append(view)

    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, '_parsed.json'), 'w') as fh:
        json.dump(parsed, fh, indent=2)

    lines = ['---',
             '# Brouillon généré depuis la conf de %s — À RELIRE.' % server,
             '# bind9_use_views: false = serveur SANS views, zones déclarées',
             '# globalement (named.conf.local). BIND interdit de mélanger.',
             'bind9_use_views: %s' % ('true' if use_views else 'false'),
             '# includes présents dans les fichiers régénérés et pointant',
             '# ailleurs : réémis dans named.conf pour ne pas être perdus.',
             ] + \
            (['bind9_extra_includes:'] +
             ['  - "%s"' % i for i in safe_includes]
             if safe_includes else []) + \
            (['  # A VERIFIER : ces include contiennent peut-etre des',
              '  # view/zone/acl desormais generees par l outil. Les',
              '  # decommenter UNIQUEMENT si ce n est pas le cas',
              '  # (sinon doublon : BIND refusera de demarrer).'] +
             ['  # - "%s"' % i for i in risky_includes]
             if risky_includes else []) + \
            [
             '# zone_dir = où sont RÉELLEMENT les zones sur ce serveur',
             '# (conservé tel quel : rien n\'est déplacé).',
             'bind9_views:']
    for v in views:
        lines.append('  - name: %s' % v['name'])
        lines.append('    match_clients:')
        lines += ['      - "%s"' % c for c in v['match_clients']]
        if 'zone_dir' in v:
            lines.append('    zone_dir: "%s"' % v['zone_dir'])
        if 'zone_paths' in v:
            lines.append('    zone_paths:')
            lines += ['      "%s": "%s"' % (z, p) for z, p in sorted(v['zone_paths'].items())]
        for s in v.get('secondary_zones', []):
            if s is v['secondary_zones'][0]:
                lines.append('    # zones secondaires : contenu géré par leur primary,')
                lines.append('    # simplement redéclarées telles quelles.')
                lines.append('    secondary_zones:')
            lines.append('      - name: %s' % s['name'])
            lines.append('        primaries: [%s]' % ', '.join('"%s"' % p for p in s['primaries']))
            lines.append('        file: "%s"' % s['file'])
    with open(os.path.join(out_dir, 'host_vars.yml.draft'), 'w') as fh:
        fh.write('\n'.join(lines) + '\n')

    nb_sec = sum(len(s) for s in secondaries.values())
    report = {'views': len(views) if use_views else 0, 'zones': len(parsed),
              'secondary': nb_sec, 'skipped': len(skipped),
              'includes': len(safe_includes),
              'includes_a_verifier': len(risky_includes),
              'use_views': use_views,
              'source': source}
    print(json.dumps(report))
    if not use_views:
        sys.stderr.write(
            'INFO : serveur SANS views (%d zones globales) — elles seront '
            'gerees dans named.conf.local via la pseudo-view _global\n'
            % len(parsed))
    for inc in risky_includes:
        sys.stderr.write(
            'ATTENTION include a verifier (contient peut-etre des zones/views '
            'desormais generees) : %s\n' % inc)
    for s in skipped:
        sys.stderr.write(
            'ATTENTION zone NON importee (type %s, non geree par cet outil) : '
            '%s dans view %s\n' % (s['type'], s['zone'], s['view']))
    with open(os.path.join(out_dir, '_skipped.json'), 'w') as fh:
        json.dump(skipped, fh, indent=2)


if __name__ == '__main__':
    main()
