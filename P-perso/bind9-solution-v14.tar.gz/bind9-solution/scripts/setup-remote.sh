#!/usr/bin/env bash
# Crée un dépôt Git "bare" sur une machine interne et l'enregistre
# comme remote. Aucun service web : uniquement SSH.
#
#   ./scripts/setup-remote.sh <user>@<hote> [/chemin/du/depot.git]
#
# Exemple :
#   ./scripts/setup-remote.sh admin@192.168.30.90
#
# À NE PAS héberger sur un serveur DNS géré par cet outil : le
# serveur serait à la fois cible et sauvegarde de sa propre
# configuration (une perte emporte les deux), et une machine exposée
# détiendrait la cartographie DNS de tout le parc.
set -euo pipefail
cd "$(dirname "$0")/.."

TARGET="${1:?Usage: $0 <user>@<hote> [/chemin/depot.git]}"
REPO_PATH="${2:-/srv/git/bind9-solution.git}"
HOST="${TARGET#*@}"

if [ ! -d .git ]; then
    echo "[remote] Aucun dépôt local : lance d'abord ./deploy.sh une fois." >&2
    exit 1
fi

echo "[remote] Création du dépôt bare sur $TARGET:$REPO_PATH"
ssh "$TARGET" "
    set -e
    sudo mkdir -p '$REPO_PATH'
    sudo chown \$(id -un):\$(id -gn) '$REPO_PATH'
    cd '$REPO_PATH'
    if [ ! -d objects ]; then
        git init --bare -q
        echo 'depot cree'
    else
        echo 'depot deja present'
    fi
"

if git remote | grep -qx origin; then
    git remote set-url origin "$TARGET:$REPO_PATH"
    echo "[remote] origin mis à jour"
else
    git remote add origin "$TARGET:$REPO_PATH"
    echo "[remote] origin ajouté"
fi

BRANCH="$(git rev-parse --abbrev-ref HEAD)"
git push -u origin "$BRANCH"

echo "[remote] Terminé. Sauvegarde : git push (automatique via deploy.sh)"
echo "[remote] Restauration sur un nouveau poste :"
echo "         git clone $TARGET:$REPO_PATH"
