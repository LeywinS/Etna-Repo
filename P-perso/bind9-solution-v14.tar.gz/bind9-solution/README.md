# Ansible BIND9 — administration centralisée multi-serveurs / multi-views

1 playbook de déploiement, 2 rôles, 1 playbook d'import. Les fichiers
de zone (format BIND standard) sont la source de vérité : le poste
admin les distribue sur tous les serveurs DNS, les valide et recharge
les services. Historique local des modifications via Git (rien n'est
publié à l'extérieur du poste admin).

- `bind9_setup` : installe BIND9, crée l'arborescence, génère
  `/etc/bind/named.conf*` (views, ACL, options, logging), valide la
  configuration (`named-checkconf`), démarre le service.
- `bind9_update_zones` : pousse les fichiers de zone vers
  `/var/cache/bind/primary/<view>/<zone>`, chacun validé par
  `named-checkzone` AVANT mise en place, reload uniquement si
  changement.
- `import.yml` : rapatrie les zones d'un serveur existant vers le
  poste admin (sas `import/`, jamais directement dans la référence).
- `deploy.sh` : déploiement tracé (commit Git local + push).

## Organisation

```
inventory/hosts.yml        # les serveurs DNS du site
host_vars/<serveur>.yml    # les views de chaque serveur (nom + réseaux)
zonefiles/
└── <serveur>/
    └── <view>/
        └── <zone>         # fichiers de zone BIND, tels quels
import/                    # sas d'import (ignoré par Git)
```

Le chemin du fichier fait office de configuration :
`zonefiles/dns01/internal/montreprise.com` = le serveur dns01 sert
cette zone dans sa view internal avec ce contenu. Les blocs `zone {}`
de `named.conf.views` sont générés automatiquement depuis les
fichiers présents — rien d'autre à déclarer. Ajouter une zone à une
view = déposer un fichier. La retirer = retirer le fichier.

## host_vars/<serveur>.yml

```yaml
bind9_views:              # ordre important : première view qui matche
  - name: internal        # l'IP source du client gagne,
    match_clients:        # "any" toujours en dernier
      - "10.10.0.0/16"
  - name: external
    match_clients: ["any"]
```

## Workflow quotidien : modifier le DNS

1. Éditer le fichier de zone concerné dans `zonefiles/` — se demander
   d'abord : QUI doit voir cet enregistrement ? -> ça donne la ou les
   views (donc le ou les fichiers) à modifier.
2. Incrémenter le Serial du fichier (+1 à chaque modification).
3. Déployer avec trace :

```bash
./deploy.sh "Ajout app.montreprise.com en internal" --tags bind9_zones -k
```

Le commit est automatique ; seuls les fichiers modifiés sont poussés ;
seuls les serveurs touchés sont rechargés.

## Mise sous gestion d'un DNS existant (une fois par serveur)

```bash
ansible-playbook import.yml -k --limit <serveur>   # pull -> import/<serveur>/
cat import/<serveur>/<view>/<zone>                 # RELIRE (sas)
mv import/<serveur>/* zonefiles/<serveur>/         # valider -> référence
ansible-playbook site.yml --check --diff -k --limit <serveur>   # LIRE le diff
./deploy.sh "Mise sous gestion de <serveur>" -k --limit <serveur>
```

Ne pas oublier : déclarer le serveur dans `inventory/hosts.yml` et
ses views dans `host_vars/<serveur>.yml`. L'import rapatrie aussi
`named.conf.views` et `named.conf.acl` dans `import/<serveur>/_conf/`
pour faciliter la transcription des views sans SSH sur chaque
serveur. Pour un parc entier : `ansible-playbook import.yml -k`
(sans --limit) importe tous les serveurs de l'inventaire d'un coup.

## Exemple complet : cycle de vie d'un serveur DNS

Scénario : un serveur BIND9 existant (dns03, 192.168.30.82, compte
SSH "admin") doit passer sous gestion, puis vivre son quotidien.

### Etape 1 — Déclarer le serveur

`inventory/hosts.yml` :

```yaml
        dns03:
          ansible_host: 192.168.30.82
          ansible_user: admin
```

Vérifier : `ansible dns03 -m ping -k` -> pong.

### Etape 2 — Importer l'existant (pull)

```bash
ansible-playbook import.yml -k --limit dns03
find import/dns03 -type f
```

Les zones arrivent dans `import/dns03/<view>/<zone>` et la conf du
serveur dans `import/dns03/_conf/` (aide pour l'étape 3).

### Etape 3 — Transcrire ses views

Lire `import/dns03/_conf/named.conf.views` (les views, LEUR ORDRE) et
`named.conf.acl` (les réseaux), puis écrire `host_vars/dns03.yml` :

```yaml
bind9_views:
  - name: interne
    match_clients:
      - "10.60.0.0/16"
  - name: externe
    match_clients: ["any"]
```

### Etape 4 — Valider les zones importées (le sas)

```bash
cat import/dns03/interne/monsite.fr        # relecture de chaque zone
mkdir -p zonefiles/dns03
mv import/dns03/interne import/dns03/externe zonefiles/dns03/
```

(ne pas déplacer `_conf/`, c'est une aide, pas une zone)

### Etape 5 — Contrôler puis officialiser

```bash
ansible-playbook site.yml --check --diff -k --limit dns03
```

LIRE le diff : quasi vide = transcription fidèle. Puis :

```bash
./deploy.sh "Mise sous gestion de dns03" -k --limit dns03
```

Attendu : changed=0 ou presque, et un commit dans `git log`.
dns03 est maintenant piloté depuis le poste admin.

### Etape 6 — Une modification du quotidien

Ajouter app.monsite.fr, visible uniquement en interne :

```bash
nano zonefiles/dns03/interne/monsite.fr
#   -> ajouter :  app IN A 10.60.5.10
#   -> incrémenter le Serial
./deploy.sh "Ajout app.monsite.fr en interne" --tags bind9_zones -k --limit dns03
```

Vérifier depuis un client interne :
`dig @192.168.30.82 app.monsite.fr A +short` -> 10.60.5.10
Depuis un client externe : NXDOMAIN (cloisonnement).

### Etape 7 — Contrôle de dérive (périodique)

```bash
ansible-playbook site.yml --check --diff -k
```

Diff vide = tout le parc conforme à la référence. Un diff non vide
révèle une modification manuelle sur un serveur ; pour l'écraser :
`./deploy.sh "Remise en conformité" --tags bind9_zones -k`.

### Etape 8 — Consulter / récupérer

```bash
git log --oneline                          # qui a fait quoi, quand
git restore zonefiles/dns03/interne/monsite.fr   # fichier supprimé
git revert <commit> && ./deploy.sh "Rollback" --tags bind9_zones -k
```

## Parc hétérogène : conserver les chemins d'origine

Les serveurs existants ne rangent pas tous leurs zones au même
endroit (`/var/cache/bind/primary`, `/etc/bind/zones`, `/DATA`...).
L'import lit `named.conf*` pour découvrir le CHEMIN RÉEL de chaque
zone, et le déploiement réécrit chaque zone à cet emplacement : rien
n'est déplacé sur le serveur.

Les chemins sont mémorisés par view dans `host_vars/<serveur>.yml` :

```yaml
bind9_views:
  - name: admin
    match_clients: ["10.30.0.0/16"]
    zone_dir: "/etc/admin"          # où vont les zones de cette view
    zone_paths:                     # exceptions, zone par zone
      "lab.local": "/var/interne/lab.local"
  - name: interne
    match_clients: ["10.60.0.0/16"]
    zone_dir: "/DATA/zones"
```

Sans `zone_dir`, la valeur par défaut est
`/var/cache/bind/primary/<view>` (serveurs déployés par l'outil).

`zone_paths` liste les exceptions : toute zone dont le chemin réel
n'est pas `<zone_dir>/<nom de la zone>` — autre dossier, ou nom de
fichier différent (convention Debian `db.example.com`). Les fichiers
sont réécrits sous leur nom d'origine.

Ce fichier n'est pas à écrire à la main : l'import en produit un
brouillon complet (views, ACL résolues, chemins) dans
`import/<serveur>/host_vars.yml.draft`.

### Import d'un serveur existant

```bash
ansible-playbook import.yml -k --limit dns03
find import/dns03 -type f                        # ce qui a été récupéré
cat import/dns03/host_vars.yml.draft             # RELIRE le brouillon
cp import/dns03/host_vars.yml.draft host_vars/dns03.yml
mkdir -p zonefiles/dns03
mv import/dns03/<view1> import/dns03/<view2> zonefiles/dns03/
ansible-playbook site.yml --check --diff -k --limit dns03
./deploy.sh "Mise sous gestion de dns03" -k --limit dns03
```

Une fois importé, ce serveur s'administre comme les autres : ajouter
une zone à une view = déposer le fichier dans
`zonefiles/dns03/<view>/`. Il sera déployé dans le `zone_dir` de la
view et déclaré automatiquement dans `named.conf.views`.

Limites du parseur (`scripts/parse_bind_conf.py`) : il lit les
fichiers `named.conf*` de `/etc/bind`, résout les ACL nommées et
ignore les commentaires, mais ne suit pas les `include` pointant
ailleurs et ne gère que les zones `type primary` ayant une directive `file`.
Les zones d'un autre type (secondary, hint, forward...) sont
IGNORÉES avec un avertissement explicite et listées dans
`import/<serveur>/_skipped.json` — elles restent à gérer hors de cet
outil. D'où le sas `import/` et la relecture avant validation.

## Ce qui est repris tel quel (jamais écrasé)

L'outil régénère `named.conf`, `.logging`, `.acl`, `.views` et
`.local`. Tout ce qu'il ne modélise pas serait perdu à la
régénération : trois mécanismes l'en empêchent.

- **`named.conf.options`** : l'import le dépose dans
  `conf/<serveur>/`, d'où il est poussé tel quel. Forwarders,
  `allow-transfer`, options propres au serveur : rien n'est perdu, et
  le fichier reste éditable depuis le poste admin.
- **Zones secondaires** : leur contenu appartient à leur primary, mais
  leur déclaration est mémorisée dans `host_vars` et réémise :

  ```yaml
  bind9_views:
    - name: production
      secondary_zones:
        - name: replique.fr
          primaries: ["10.0.0.1"]
          file: "/var/cache/bind/sec/replique.fr"
  ```

- **Includes supplémentaires** : tout `include` présent dans un
  fichier régénéré et pointant ailleurs est collecté à l'import dans
  `bind9_extra_includes` et réémis dans `named.conf`. Un include dont
  le fichier contient des `view`/`zone`/`acl` — donc du contenu
  désormais généré par l'outil — est mis en commentaire dans le
  brouillon avec un avertissement : le réémettre créerait des
  doublons et BIND refuserait de démarrer.

### Résolution des includes

L'import exécute `named-checkconf -p` sur le serveur : BIND rend sa
configuration telle qu'il la charge, tous les `include` suivis à tous
les niveaux, y compris vers des fichiers hors `/etc/bind` ou aux noms
non standards. C'est cette configuration résolue qui est analysée —
les zones déclarées au fond d'un arbre d'includes ne peuvent donc pas
être manquées. Si la commande échoue, l'analyse se replie sur les
fichiers `/etc/bind/named.conf*` et un avertissement explicite le
signale (des zones peuvent alors manquer).

## Sécurité du déploiement de la configuration

Les fichiers sont sauvegardés avant écrasement (`backup: true`). Si
`named-checkconf` échoue, les fichiers précédents sont RESTAURÉS et le
play échoue : le service n'est pas rechargé et aucune configuration
invalide ne reste sur le disque (ce qui empêcherait BIND de redémarrer
plus tard).

## Serveurs sans views

BIND interdit de mélanger zones globales et views : un serveur est
soit entièrement en views, soit entièrement sans. Les deux modes sont
supportés, serveur par serveur.

L'import détecte le mode et l'inscrit dans le brouillon `host_vars` :

```yaml
bind9_use_views: false      # serveur SANS views
bind9_views:
  - name: _global           # pseudo-view : les zones globales
    match_clients: ["any"]
    zone_dir: "/etc/bind"   # leur emplacement réel
```

En mode sans views, les zones vivent dans
`zonefiles/<serveur>/_global/` et sont déclarées dans
`named.conf.local` ; `named.conf.views` reste vide. Le reste ne
change pas : déposer un fichier suffit à ajouter une zone, les
chemins d'origine sont conservés, et les garde-fous s'appliquent de
la même façon.

Un serveur dont `bind9_views` est vide est REFUSÉ au déploiement
(toutes ses zones seraient désenregistrées).

## Éditer directement les fichiers de configuration (optionnel)

Par défaut, `/etc/bind/named.conf*` est généré depuis les templates
et les views déclarées en `host_vars/`. Il est aussi possible de
fournir un fichier BRUT, édité à la main, qui remplace le template
pour un serveur donné :

```
conf/<serveur>/named.conf.acl        # ACL écrites à la main
conf/<serveur>/named.conf.options    # options propres à ce serveur
conf/<serveur>/named.conf.views      # voir l'avertissement ci-dessous
```

Le fichier est poussé tel quel, puis la configuration complète est
validée par `named-checkconf` comme d'habitude. Sans fichier dans
`conf/`, le template s'applique normalement — les deux modes
cohabitent, fichier par fichier et serveur par serveur.

Point de vigilance : si `named.conf.views` est fourni à la main, la
génération automatique des blocs `zone {}` depuis `zonefiles/` est
désactivée pour ce serveur — il faudra déclarer chaque zone à la main
dans ce fichier. Pour `named.conf.acl` et `named.conf.options`,
aucun effet de bord : c'est le moyen le plus simple de reprendre
telles quelles les ACL d'un serveur existant sans les retranscrire
en YAML.

Workflow typique après un import :

```bash
ansible-playbook import.yml -k --limit dns03
mkdir -p conf/dns03
cp import/dns03/_conf/named.conf.acl conf/dns03/     # repris tel quel
ansible-playbook site.yml --check --diff -k --limit dns03
```

## Dépôt Git distant sans GitLab

Pour sauvegarder l'historique ailleurs que sur le poste admin (ou
travailler à plusieurs) sans service web : un dépôt "bare" accessible
en SSH suffit. Sur la machine hôte choisie :

```bash
sudo mkdir -p /srv/git/bind9-solution.git
sudo chown admin: /srv/git/bind9-solution.git
cd /srv/git/bind9-solution.git && git init --bare
```

Depuis le poste admin :

```bash
git remote add origin admin@<ip_hote>:/srv/git/bind9-solution.git
git push -u origin master
```

Ensuite `git push` après chaque `./deploy.sh`. Rien n'est exposé sur
le web : seul SSH est utilisé, sur une machine interne.

Remarque : héberger ce dépôt sur un serveur DNS du parc est possible
mais discutable — le serveur devient à la fois cible gérée et
sauvegarde de la référence, ce qui concentre le risque (une perte du
serveur emporte les deux). Un hôte tiers (poste admin secondaire,
serveur de fichiers interne) est préférable.

## Vérifications avec named-* et rndc

Sur un serveur, avant / après un déploiement :

```bash
named-checkconf /etc/bind/named.conf      # syntaxe conf (silence = OK)
named-checkconf -z /etc/bind/named.conf   # + charge toutes les zones
named-checkzone <zone> /var/cache/bind/primary/<view>/<zone>
```

État du service et des zones (rndc = télécommande de BIND) :

```bash
sudo rndc status                          # version, nb de zones, uptime
sudo rndc zonestatus <zone> IN <view>     # serial chargé, dernier reload
sudo rndc reload                          # recharger toute la conf
sudo rndc reload <zone> IN <view>         # recharger UNE zone d'UNE view
sudo rndc reconfig                        # relire la conf + nouvelles zones
sudo rndc dumpdb -zones                   # dump des zones en mémoire
                                          #  -> /var/cache/bind/named_dump.db
sudo rndc querylog on                     # tracer les requêtes (debug)
sudo rndc querylog off                    # (à couper après diagnostic)
```

Logs : `journalctl -u bind9 -n 50` ou `/var/log/named/`.

Le playbook utilise `named-checkzone` / `named-checkconf` avant toute
mise en place et un reload par handler : ces commandes servent donc
surtout au diagnostic manuel et à la vérification indépendante.

## Hors périmètre : DNSSEC

Les zones signées ne sont pas supportées. Avec DNSSEC, BIND ne sert
pas le fichier source mais une version signée qu'il régénère et
resigne périodiquement (fichiers `.signed`, journaux `.jnl`). Pousser
notre copie par-dessus casserait les signatures — et une signature
invalide fait REJETER les réponses par tous les résolveurs validants,
ce qui est pire qu'une zone absente.

Un serveur présentant `dnssec-policy`, `inline-signing`,
`auto-dnssec` ou des fichiers `.signed` ne doit donc pas être placé
sous gestion : ses zones sont à administrer hors de cet outil.

## Sauvegarde de l'historique (dépôt distant)

L'historique Git vit sur le poste admin. Pour le sauvegarder ailleurs
sans service web, un dépôt "bare" accessible en SSH suffit :

```bash
./scripts/setup-remote.sh admin@<hote_interne>
```

Le script crée le dépôt sur l'hôte, l'enregistre comme `origin` et
pousse l'historique. Ensuite, `deploy.sh` pousse automatiquement après
chaque déploiement réussi ; un remote injoignable n'interrompt pas le
déploiement (avertissement seulement).

Restauration sur un poste neuf :
`git clone admin@<hote_interne>:/srv/git/bind9-solution.git`

À ne pas héberger sur un serveur DNS géré par l'outil : il serait à la
fois cible et sauvegarde de sa propre configuration, et détiendrait la
cartographie DNS du parc.

## Schéma des flux

Voir `SCHEMA.md` : vue d'ensemble des trois flux (import, déploiement,
sauvegarde) et commandes de chaque action.

## Contrôles automatiques au déploiement

- **Nom de fichier / zone** : le nom du fichier sert de nom de zone.
  S'il ne correspond pas au `$ORIGIN` déclaré dans le fichier, le
  déploiement est refusé (une zone au mauvais nom ne résoudrait pour
  personne). Les fichiers sans `$ORIGIN` ne sont pas contrôlés.
- **Serial** : si une zone est modifiée sans que son serial change, un
  avertissement est affiché — les serveurs secondaires ne se
  resynchroniseraient pas. Le fichier n'est jamais modifié
  automatiquement.
- **Droits** : seuls les dossiers créés par l'outil reçoivent
  `bind:bind 0755` ; les dossiers existants d'un serveur importé ne
  sont pas modifiés.
- **Historique** : un déploiement en échec est marqué `[ECHEC]` dans
  l'historique Git, pour que `git log` reflète ce qui est réellement
  en production.

## Tests

```bash
python3 tests/run_tests.py        # tests du parseur (aucun serveur requis)
ansible-playbook --syntax-check site.yml
ansible-playbook --syntax-check import.yml
```

`tests/run_tests.py` vérifie que le parseur lit correctement cinq cas
de configuration (views multiples avec ACL nommées, serveur sans
views avec fichiers `db.*`, chemins hétérogènes, zones secondaires,
commentaires). À lancer après toute modification de
`scripts/parse_bind_conf.py` : un échec signale une régression sur un
cas déjà validé.

## Recette de validation

Le fichier `TESTS.md` contient un scénario de test complet (import
hétérogène, cycle de vie des zones et des views, dérive, garde-fou,
rollback, idempotence) avec les résultats attendus à chaque étape.

## Commandes de référence

### Déploiement

```bash
./deploy.sh "message" -k                        # tout (setup + zones), tracé
./deploy.sh "message" --tags bind9_zones -k     # zones uniquement
./deploy.sh "message" -k --limit dns01          # un seul serveur
ansible-playbook site.yml -k                    # sans trace Git (déconseillé)
```

### Contrôle avant / après

```bash
ansible-playbook --syntax-check site.yml        # syntaxe du playbook
ansible-playbook site.yml --check --diff -k     # dry-run : montre ce qui
                                                #  changerait, ne touche rien
ansible bind_servers -m ping -k                 # connectivité de tout le parc
ansible-inventory --graph                       # qui est dans l'inventaire
```

### Détection de dérive (modification manuelle sur un serveur)

```bash
ansible-playbook site.yml --check --diff -k     # le diff montre tout écart
./deploy.sh "Remise en conformité" --tags bind9_zones -k   # écrase l'écart
```

### Historique et récupération (Git local)

```bash
git log --oneline                     # historique des modifications
git log -p zonefiles/dns01/internal/montreprise.com   # détail d'un fichier
git blame zonefiles/dns01/internal/montreprise.com    # qui/quand par ligne
git restore zonefiles/dns01/internal/lab.local # récupérer un fichier
                                               #  supprimé (dernier commit)
git revert <commit>                   # annuler une modification
                                      #  (puis ./deploy.sh pour appliquer)
git diff                              # modifs locales pas encore commitées
```

Fichier supprimé du poste admin : deux filets de récupération.
`git restore` rend la dernière version commitée ; `import.yml` rend
la version présente sur le serveur (celle du dernier push). Les deux
couvrent tout ce qui est passé par `deploy.sh` — d'où l'importance de
toujours déployer via le wrapper.

### Vérification DNS côté client

```bash
dig @<ip_serveur> www.montreprise.com A +short  # réponse selon la view
dig @<ip_serveur> <nom> A | grep status         # NOERROR / NXDOMAIN / REFUSED
```

NXDOMAIN = la zone existe pour ce client mais pas l'enregistrement ;
REFUSED = la zone n'existe pas dans sa view. Même question posée
depuis des réseaux différents = réponses différentes (split-horizon).

### Diagnostic sur un serveur

```bash
systemctl status bind9                # état du service
rndc status                           # état de BIND
named-checkconf /etc/bind/named.conf  # valider la conf (silence = OK)
named-checkzone <zone> /var/cache/bind/primary/<view>/<zone>
journalctl -u bind9 -n 50             # derniers logs du service
```

## Garde-fous intégrés

- Fichier de zone invalide rejeté par `named-checkzone` avant mise en
  place ; configuration validée par `named-checkconf` avant reload —
  dans les deux cas le service continue avec l'ancienne configuration.
- Reload uniquement si changement réel ; le playbook est rejouable à
  l'infini sans effet de bord (`changed=0`).
- Si le dossier `zonefiles/<serveur>/<view>/` d'une view est VIDE, le
  déploiement REFUSE (un dossier vide est presque toujours une erreur
  et déploierait un serveur sans zones). Vidage volontaire :
  `-e bind9_allow_empty_views=true`.
- Le flux est à sens unique : le dépôt est la source de vérité,
  `site.yml` ne sait que pousser, `import.yml` ne sait que tirer (et
  uniquement vers le sas `import/`).

## Rappels de syntaxe zone BIND

- Serial : +1 à CHAQUE modification (convention AAAAMMJJnn possible).
- Noms absolus terminés par un point (`ns1.montreprise.com.`), sinon
  `$ORIGIN` est concaténé.
- Tout NS déclaré doit avoir un enregistrement A/AAAA.
