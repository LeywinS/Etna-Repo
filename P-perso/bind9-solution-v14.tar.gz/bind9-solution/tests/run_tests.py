#!/usr/bin/env python3
"""Tests du parseur de configuration BIND.

    python3 tests/run_tests.py

Chaque cas décrit une configuration (tests/fixtures/*.conf) et ce que
le parseur doit en déduire. Un échec signale une régression : le
parseur ne lit plus correctement un cas déjà validé.
"""
import json
import os
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PARSER = os.path.join(ROOT, 'scripts', 'parse_bind_conf.py')

# fichier, rapport attendu (sous-ensemble), assertions sur le brouillon
CASES = [
    {
        'name': 'Views multiples, ACL nommées résolues',
        'conf': '01-views-simple.conf',
        'report': {'views': 3, 'zones': 3, 'use_views': True},
        'draft_contains': ['bind9_use_views: true', 'name: admin',
                           '"10.30.0.0/16"', 'name: external', '"any"'],
        'draft_excludes': ['admin_clients'],      # ACL doit être résolue
    },
    {
        'name': 'Serveur sans views, fichiers db.* (chemins préservés)',
        'conf': '02-sans-views.conf',
        'report': {'views': 0, 'zones': 2, 'use_views': False},
        'draft_contains': ['bind9_use_views: false', 'name: _global',
                           'zone_dir: "/etc/bind/zones"',
                           '"classique.fr": "/etc/bind/zones/db.classique.fr"'],
        'skipped_types': ['hint'],                 # zone racine écartée
    },
    {
        'name': 'Chemins hétérogènes dans une même view',
        'conf': '03-hetero-paths.conf',
        'report': {'views': 2, 'zones': 3, 'use_views': True},
        # peu importe lequel des deux dossiers devient zone_dir : ce qui
        # compte est que chaque zone conserve son chemin réel
        'draft_contains': ['zone_paths:', '/DATA/legacy',
                           '/var/cache/bind/primary/production/autresite.fr'],
    },
    {
        'name': 'Zones secondaires conservées (non supprimées)',
        'conf': '04-secondaires.conf',
        'report': {'views': 1, 'zones': 1, 'secondary': 1},
        'draft_contains': ['secondary_zones:', 'name: replique.fr',
                           'primaries: ["10.0.0.1", "10.0.0.2"]'],
    },
    {
        'name': 'View au chemin par défaut (zone_dir = racine/view)',
        'conf': '06-view-sans-zonedir.conf',
        'report': {'views': 1, 'zones': 1},
        'draft_contains': ['name: nouvelle',
                           'zone_dir: "/var/cache/bind/primary/nouvelle"'],
        'draft_excludes': ['zone_paths'],
    },
    {
        'name': 'Commentaires (//, #, /* */) ignorés',
        'conf': '05-commentaires.conf',
        'report': {'views': 1, 'zones': 1},
        'draft_contains': ['name: interne'],
        'draft_excludes': ['desactivee.fr'],       # zone commentée
    },
]


def run_case(case):
    conf = os.path.join(HERE, 'fixtures', case['conf'])
    errors = []
    with tempfile.TemporaryDirectory() as tmp:
        conf_dir = os.path.join(tmp, '_conf')
        os.makedirs(conf_dir)
        # le parseur lit soit un dossier named.conf*, soit une conf résolue
        proc = subprocess.run(
            [sys.executable, PARSER, conf_dir, 'testsrv', tmp, conf],
            capture_output=True, text=True)
        if proc.returncode != 0:
            return ['le parseur a échoué : %s' % proc.stderr.strip()]

        report = json.loads(proc.stdout)
        for key, expected in case.get('report', {}).items():
            if report.get(key) != expected:
                errors.append('%s attendu %r, obtenu %r'
                              % (key, expected, report.get(key)))

        with open(os.path.join(tmp, 'host_vars.yml.draft')) as fh:
            draft = fh.read()
        for needle in case.get('draft_contains', []):
            if needle not in draft:
                errors.append('brouillon : %r manquant' % needle)
        for needle in case.get('draft_excludes', []):
            if needle in draft:
                errors.append('brouillon : %r présent alors qu\'il ne devrait pas'
                              % needle)

        with open(os.path.join(tmp, '_skipped.json')) as fh:
            skipped = json.load(fh)
        for ztype in case.get('skipped_types', []):
            if not any(s['type'].startswith(ztype) for s in skipped):
                errors.append('zone de type %s non écartée' % ztype)
    return errors


def main():
    failures = 0
    for case in CASES:
        errors = run_case(case)
        if errors:
            failures += 1
            print('ECHEC  %s' % case['name'])
            for err in errors:
                print('       - %s' % err)
        else:
            print('OK     %s' % case['name'])
    print('\n%d/%d cas valides' % (len(CASES) - failures, len(CASES)))
    return 1 if failures else 0


if __name__ == '__main__':
    sys.exit(main())
