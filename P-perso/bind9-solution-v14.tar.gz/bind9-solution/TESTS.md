# Recette de validation de la pipeline

Scénario de test complet, à dérouler dans l'ordre. Chaque étape
indique le résultat attendu ; si l'attendu n'est pas obtenu, ne pas
passer à la suivante.

## Banc de test

| Rôle | Machine | Détail |
|---|---|---|
| Poste admin | le poste de travail | contient ce dépôt, lance les playbooks |
| dns01 | 192.168.30.80 | 3 views : admin / internal / external |
| dns02 | 192.168.30.81 | 2 views : production / public, chemins hétérogènes |
| Client A | 192.168.30.71 | view internal (dns01), production (dns02) |
| Client B | 192.168.30.72 | view admin (dns01) |
| Client C | le poste admin | view external (dns01), public (dns02) |

Prérequis : `dig` installé sur les clients (`apt install bind9-dnsutils`),
SSH accessible sur les serveurs, `sshpass` sur le poste admin si
authentification par mot de passe (option `-k`).

---

## Étape 0 — Préparation

```bash
python3 tests/run_tests.py          # tests du parseur, hors ligne
ansible bind_servers -m ping -k
ansible-playbook --syntax-check site.yml
```

**Attendu** : un `pong` par serveur, syntaxe valide.

---

## Étape 1 — Créer un cas hétérogène (optionnel)

Simule un serveur "hérité" dont une zone est rangée hors des chemins
standards. Sur dns02 :

```bash
sudo mkdir -p /DATA/legacy
sudo tee /DATA/legacy/vieuxsite.fr > /dev/null << 'EOF'
$TTL 3600
$ORIGIN vieuxsite.fr.
@ IN SOA ns1.vieuxsite.fr. admin.vieuxsite.fr. ( 1 604800 86400 2419200 604800 )
@ IN NS ns1.vieuxsite.fr.
ns1 IN A 192.168.30.81
app IN A 10.99.0.10
EOF
sudo chown bind:bind /DATA/legacy/vieuxsite.fr
sudo chmod 755 /DATA /DATA/legacy
```

Déclarer la zone DANS le bloc `view "production"` de
`/etc/bind/named.conf.views` (règle : `zone "X"` -> `file ".../X"`) :

```
    zone "vieuxsite.fr" {
        type primary;
        file "/DATA/legacy/vieuxsite.fr";
        allow-query { production_clients; };
    };
```

AppArmor confine `named` : autoriser le nouveau chemin, sinon la zone
ne se chargera pas (`permission denied` dans les logs).

```bash
echo '/DATA/** rw,' | sudo tee -a /etc/apparmor.d/local/usr.sbin.named
sudo systemctl reload apparmor
sudo named-checkconf /etc/bind/named.conf
sudo systemctl restart bind9
sudo rndc zonestatus vieuxsite.fr IN production
```

**Attendu** : `zonestatus` affiche la zone avec
`files: /DATA/legacy/vieuxsite.fr` et `serial: 1`.
Depuis le client A : `dig @192.168.30.81 app.vieuxsite.fr A +short`
-> `10.99.0.10`.

---

## Étape 2 — Import du parc

```bash
ansible-playbook import.yml -k
find import -type f | sort
cat import/dns02/host_vars.yml.draft
cat import/dns02/_skipped.json
```

**Attendu** :
- chaque zone récupérée à son chemin réel, rangée en
  `import/<serveur>/<view>/<zone>` (le label affiche `<- /chemin/réel`)
- les `named.conf*` dans `import/<serveur>/_conf/`
- un brouillon `host_vars.yml.draft` par serveur, contenant les views,
  les ACL résolues en réseaux, et pour dns02 un `zone_paths` avec les
  DEUX chemins distincts de la view production
- `_skipped.json` vide (ou listant les zones non-primary ignorées)

---

## Étape 3 — Mise sous gestion (sas)

```bash
cat import/dns02/production/vieuxsite.fr        # relecture
cp import/dns01/host_vars.yml.draft host_vars/dns01.yml
cp import/dns02/host_vars.yml.draft host_vars/dns02.yml
cp -r import/dns01/admin import/dns01/internal import/dns01/external zonefiles/dns01/
cp -r import/dns02/production import/dns02/public zonefiles/dns02/
```

Restreindre la view `production` dans `host_vars/dns02.yml`
(`192.168.30.71/32` au lieu du /24) pour rendre la view `public`
testable depuis le poste admin.

```bash
ls zonefiles/dns02/production/
```

**Attendu** : `autresite.fr` ET `vieuxsite.fr` présents.

---

## Étape 4 — Contrôle puis état de référence

```bash
ansible-playbook site.yml --check --diff -k
```

**Attendu** : le diff ne montre que les changements voulus (la
restriction d'ACL). Les directives `file` de `named.conf.views`
conservent les chemins d'origine, dont `/DATA/legacy/vieuxsite.fr`.

```bash
./deploy.sh "Etat de reference du parc" -k
ssh admin@192.168.30.81 "ls -l /DATA/legacy/"
```

**Attendu** : `vieuxsite.fr` toujours dans `/DATA/legacy/` — aucun
fichier déplacé.

Vérifications DNS :

| Depuis | Requête | Attendu |
|---|---|---|
| Client A | `app.vieuxsite.fr @dns02` | 10.99.0.10 |
| Client A | `app.autresite.fr @dns02` | 10.50.0.10 |
| Client C | `app.autresite.fr @dns02` | 203.0.113.50 |
| Client C | `app.vieuxsite.fr @dns02` | REFUSED |

---

## Étape 5 — Modifier une zone (chemin hétérogène)

Éditer `zonefiles/dns02/production/vieuxsite.fr` : ajouter
`api IN A 10.99.0.20` et incrémenter le Serial (1 -> 2).

```bash
./deploy.sh "Ajout api.vieuxsite.fr" --tags bind9_zones -k --limit dns02
```

**Attendu** : un seul `changed`, avec le label
`production/vieuxsite.fr -> /DATA/legacy/vieuxsite.fr`, puis le
handler `Reload bind9`. Depuis le client A :
`dig @192.168.30.81 api.vieuxsite.fr A +short` -> `10.99.0.20`.

---

## Étape 6 — Ajouter une zone

Créer `zonefiles/dns01/internal/pipeline.fr` :

```
$TTL 3600
$ORIGIN pipeline.fr.
@ IN SOA ns1.pipeline.fr. admin.pipeline.fr. ( 1 604800 86400 2419200 604800 )
@ IN NS ns1.pipeline.fr.
ns1 IN A 192.168.30.80
www IN A 10.10.77.77
```

```bash
./deploy.sh "Ajout zone pipeline.fr en internal" -k --limit dns01
```

Playbook COMPLET (pas `--tags bind9_zones`) : la configuration doit
être régénérée pour déclarer le bloc `zone {}`.

**Attendu** : client A -> `www.pipeline.fr` = `10.10.77.77` ;
client C -> REFUSED (zone absente de la view external).

---

## Étape 7 — Ajouter une view et démontrer l'ordre

Dans `host_vars/dns01.yml`, ajouter la view `dmz` AVANT `admin`, avec
`match_clients: ["192.168.30.72/32"]` (l'IP du client B, déjà en
admin). Créer `zonefiles/dns01/dmz/partenaires.fr` (SOA, NS,
`www IN A 10.40.1.1`).

```bash
./deploy.sh "Ajout view dmz sur dns01" -k --limit dns01
```

**Attendu depuis le client B** : `www.partenaires.fr` = `10.40.1.1`,
mais `www.montreprise.com` = **REFUSED** — le client a basculé dans
`dmz`, première view qui matche, et a perdu l'accès aux zones de
`admin`. La configuration est valide : l'ordre seul a provoqué la
coupure.

Corriger en déplaçant `dmz` APRÈS `admin`, puis :

```bash
./deploy.sh "Correction ordre des views" -k --limit dns01
```

**Attendu depuis le client B** : `www.montreprise.com` répond à
nouveau, `www.partenaires.fr` devient REFUSED (view `dmz` masquée).

---

## Étape 8 — Supprimer une zone, puis une view

```bash
rm zonefiles/dns01/internal/pipeline.fr
./deploy.sh "Retrait zone pipeline.fr" -k --limit dns01
```

**Attendu** : client A -> `www.pipeline.fr` = REFUSED. Sur le
serveur, le FICHIER existe toujours (`ls /var/cache/bind/primary/internal/`) :
le déploiement désenregistre, il ne supprime jamais de fichier
distant.

Retirer le bloc `dmz` de `host_vars/dns01.yml` ET son dossier :

```bash
rm -r zonefiles/dns01/dmz
./deploy.sh "Retrait view dmz" -k --limit dns01
ssh admin@192.168.30.80 "grep '^view' /etc/bind/named.conf.views"
```

**Attendu** : 3 views restantes, `dmz` absente.

---

## Étape 9 — Dérive et garde-fou

Modification manuelle sur un serveur :

```bash
ssh admin@192.168.30.81 "echo 'pirate IN A 6.6.6.6' | sudo tee -a /DATA/legacy/vieuxsite.fr"
ansible-playbook site.yml --check --diff -k --limit dns02
```

**Attendu** : le diff affiche `-pirate IN A 6.6.6.6` (la ligne serait
retirée). Remise en conformité :

```bash
./deploy.sh "Remise en conformite dns02" --tags bind9_zones -k --limit dns02
```

Garde-fou anti-dossier vide :

```bash
mv zonefiles/dns02/public /tmp/backup-public
ansible-playbook site.yml -k --limit dns02
mv /tmp/backup-public zonefiles/dns02/public
```

**Attendu** : `REFUS DE DEPLOYER : aucune zone trouvée dans ...`,
`failed=1`, arrêt à la première tâche, serveur intact.

---

## Étape 10 — Historique et rollback

```bash
git log --oneline
git log -p zonefiles/dns02/production/vieuxsite.fr
```

**Attendu** : un commit par déploiement, et l'historique détaillé de
la zone (Serial et enregistrements, avec auteur et date).

```bash
git revert <hash du commit "Ajout api.vieuxsite.fr"> --no-edit
./deploy.sh "Rollback api.vieuxsite.fr" --tags bind9_zones -k --limit dns02
```

**Attendu** : depuis le client A, `api.vieuxsite.fr` -> NXDOMAIN
(l'enregistrement a disparu) et `app.vieuxsite.fr` -> `10.99.0.10`
(le reste de la zone intact).

---

## Étape 11 — Idempotence

```bash
ansible-playbook site.yml -k
```

**Attendu** : `changed=0` sur tous les serveurs, aucun handler
déclenché.

---

## Nettoyage

```bash
rm -rf import
ssh admin@192.168.30.80 "sudo rm -f /var/cache/bind/primary/internal/pipeline.fr"
```

---

## Grille de résultats

| # | Fonction validée | OK |
|---|---|---|
| 2 | Import multi-serveurs, chemins réels découverts | |
| 2 | Brouillon host_vars généré (views, ACL, zone_paths) | |
| 4 | Chemins d'origine préservés (rien n'est déplacé) | |
| 4 | Split-horizon (réponses différentes selon le client) | |
| 5 | Modification d'une zone à chemin hétérogène | |
| 6 | Ajout d'une zone | |
| 7 | Ajout d'une view + effet de l'ordre des views | |
| 8 | Suppression d'une zone / d'une view | |
| 9 | Détection de dérive | |
| 9 | Garde-fou dossier vide | |
| 10 | Historique local et rollback | |
| 11 | Idempotence | |

## Interprétation des réponses DNS

- **NOERROR** : la zone est servie à ce client et l'enregistrement existe.
- **NXDOMAIN** : la zone est servie mais l'enregistrement n'existe pas
  dans cette view.
- **REFUSED** : la zone n'existe pas dans la view où tombe ce client.
- **SERVFAIL** : la zone est déclarée mais BIND n'a pas pu la charger
  (droits, AppArmor, syntaxe) — voir `/var/log/named/default.log`.
