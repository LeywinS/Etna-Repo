$TTL  604800
$ORIGIN montreprise.com.
@ IN  SOA ns1.montreprise.com. admin.montreprise.com. (
            2   ; Serial
       604800   ; Refresh
        86400   ; Retry
      2419200   ; Expire
       604800 ) ; Negative Cache TTL
;
@ IN  NS  ns1.montreprise.com.
@ IN  MX  10 mx1

ns1 IN  A 10.0.0.2
mx1 IN  A 10.0.0.3
www IN  A 203.0.113.10
