#!/usr/bin/env bash
# Déploiement tracé : enregistre la modification dans l'historique
# Git LOCAL (rien ne quitte le poste admin), puis pousse sur les
# serveurs DNS. Usage :
#   ./deploy.sh "Ajout demo.montreprise.com en internal" [options ansible]
# Exemples :
#   ./deploy.sh "MAJ zone montreprise.com" --tags bind9_zones -k
#   ./deploy.sh "Nouvelle view dmz sur dns02" -k --limit dns02
set -euo pipefail
cd "$(dirname "$0")"

MSG="${1:?Usage: ./deploy.sh \"message de modification\" [options ansible-playbook]}"
shift

# Dépôt Git local initialisé au premier lancement
if [ ! -d .git ]; then
    git init -q
    git add -A
    git commit -q -m "Etat initial"
    echo "[deploy] Dépôt Git local initialisé (.git/ — ne quitte pas ce poste)"
fi

# 1. Enregistrer l'état AVANT déploiement
if ! git diff --quiet || ! git diff --cached --quiet || [ -n "$(git status --porcelain)" ]; then
    git add -A
    git commit -q -m "$MSG"
    echo "[deploy] Commit: $MSG"
else
    echo "[deploy] Aucune modification locale à enregistrer"
fi

# 2. Pousser sur les serveurs. En cas d'échec, l'historique doit le
# refléter : sinon un commit laisse croire à un déploiement réussi.
if ansible-playbook site.yml "$@"; then
    echo "[deploy] OK — historique : git log --oneline | head"
    # Sauvegarde hors du poste admin si un remote est configuré
    # (voir scripts/setup-remote.sh). Un remote injoignable ne fait
    # pas échouer le déploiement, déjà appliqué.
    if git remote | grep -qx origin; then
        if git push -q origin HEAD 2>/dev/null; then
            echo "[deploy] Historique sauvegardé sur origin"
        else
            echo "[deploy] ATTENTION : push vers origin impossible (sauvegarde non à jour)"
        fi
    fi
else
    rc=$?
    git commit -q --allow-empty -m "[ECHEC] $MSG (déploiement non appliqué)"
    echo "[deploy] ECHEC du déploiement (code $rc) — marqué dans l'historique."
    echo "[deploy] Corrige puis relance ; rien n'a été appliqué sur les serveurs en erreur."
    exit "$rc"
fi
