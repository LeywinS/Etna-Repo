Fichiers de configuration BIND édités À LA MAIN (optionnel).

Un fichier placé ici en conf/<serveur>/<nom> REMPLACE le template
Jinja2 correspondant pour ce serveur uniquement. Exemples :

  conf/dns01/named.conf.acl      -> ACL écrites à la main
  conf/dns01/named.conf.options  -> options spécifiques à ce serveur

Sans fichier ici, le template génère la conf automatiquement.

ATTENTION pour named.conf.views : si tu l'écris à la main, la
génération automatique des blocs zone{} depuis zonefiles/ est
désactivée pour ce serveur — les zones devront être déclarées à la
main dans ce fichier. Pour les ACL/options, aucun effet de bord.
