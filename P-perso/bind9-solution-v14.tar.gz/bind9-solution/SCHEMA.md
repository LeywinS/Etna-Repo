# Schéma des flux et commandes

## Vue d'ensemble

```
                     POSTE ADMIN (référence)
        ┌──────────────────────────────────────────────┐
        │  inventory/hosts.yml   quels serveurs        │
        │  host_vars/<srv>.yml   views, chemins, sec.  │
        │  zonefiles/<srv>/<view>/<zone>   les zones   │
        │  conf/<srv>/<fichier>  confs reprises        │
        │  .git/                 historique local      │
        └──────────────────────────────────────────────┘
             ▲                    │                 │
   import.yml│ (1 fois/serveur)   │ site.yml        │ git push
             │                    │ deploy.sh       ▼
        ┌────┴────────────────────▼──────┐   ┌──────────────┐
        │   SERVEURS DNS (dns01, dns02…) │   │ DÉPÔT DISTANT│
        │   /etc/bind/named.conf*        │   │ (bare, SSH)  │
        │   zones à leur emplacement     │   │ sauvegarde   │
        └────────────────────────────────┘   └──────────────┘

Flux à sens unique : la référence décide, les serveurs suivent.
import.yml ne remplit jamais la référence directement (sas import/).
```

## Commandes par action

### Mettre un serveur existant sous gestion (une fois)

```bash
# 1. le déclarer
nano inventory/hosts.yml            # nom, ansible_host, ansible_user
ansible <srv> -m ping -k

# 2. importer (zones + conf + brouillon host_vars)
ansible-playbook import.yml -k --limit <srv>
find import/<srv> -type f
cat import/<srv>/host_vars.yml.draft

# 3. relire puis valider (le sas)
cat import/<srv>/<view>/<zone>
cp import/<srv>/host_vars.yml.draft host_vars/<srv>.yml
mkdir -p zonefiles/<srv>
cp -r import/<srv>/<view> zonefiles/<srv>/

# 4. contrôler AVANT de déployer
ansible-playbook site.yml --check --diff -k --limit <srv>

# 5. officialiser
./deploy.sh "Mise sous gestion de <srv>" -k --limit <srv>
```

### Modifier un enregistrement

```bash
nano zonefiles/<srv>/<view>/<zone>   # + incrémenter le Serial
./deploy.sh "Ajout app.<zone>" --tags bind9_zones -k --limit <srv>
dig @<ip_srv> app.<zone> A +short    # depuis un client de la view
```

### Ajouter une zone à une view

```bash
nano zonefiles/<srv>/<view>/<nouvelle.zone>
./deploy.sh "Ajout zone <nouvelle.zone>" -k --limit <srv>
```

Playbook complet (sans `--tags`) : la configuration doit être
régénérée pour déclarer la zone.

### Retirer une zone d'une view

```bash
rm zonefiles/<srv>/<view>/<zone>
./deploy.sh "Retrait zone <zone>" -k --limit <srv>
```

Le fichier reste sur le serveur : il est désenregistré, pas supprimé.

### Ajouter / retirer une view

```bash
nano host_vars/<srv>.yml             # bloc name + match_clients
                                     # ORDRE = priorité, "any" en dernier
mkdir -p zonefiles/<srv>/<view>      # au moins une zone, sinon refus
nano zonefiles/<srv>/<view>/<zone>
./deploy.sh "Ajout view <view>" -k --limit <srv>

# retrait : enlever le bloc du host_vars ET le dossier
rm -r zonefiles/<srv>/<view>
./deploy.sh "Retrait view <view>" -k --limit <srv>
```

### Vérifier la conformité du parc (dérive)

```bash
ansible-playbook site.yml --check --diff -k        # tout le parc
./deploy.sh "Remise en conformité" --tags bind9_zones -k
```

### Historique, retour arrière

```bash
git log --oneline
git log -p zonefiles/<srv>/<view>/<zone>
git restore zonefiles/<srv>/<view>/<zone>          # fichier supprimé
git revert <commit> --no-edit
./deploy.sh "Rollback" --tags bind9_zones -k
```

### Sauvegarde hors du poste admin

```bash
./scripts/setup-remote.sh admin@<hote_interne>     # une fois
# ensuite : push automatique après chaque déploiement réussi
git clone admin@<hote_interne>:/srv/git/bind9-solution.git   # restauration
```

### Tests et diagnostic

```bash
python3 tests/run_tests.py                 # parseur, hors ligne
ansible-playbook --syntax-check site.yml
ansible-inventory --graph                  # périmètre réel

# sur un serveur
systemctl status bind9
named-checkconf /etc/bind/named.conf
rndc zonestatus <zone> IN <view>
tail -30 /var/log/named/default.log
```

## Règles à retenir

| Ce que tu modifies | Commande |
|---|---|
| Un enregistrement dans une zone existante | `--tags bind9_zones` |
| Ajout / retrait d'une zone | playbook complet |
| Ajout / retrait / modification d'une view | playbook complet |

- Le Serial se met à jour à chaque modification de contenu.
- Le nom du fichier de zone doit correspondre à son `$ORIGIN`.
- L'ordre des views décide qui voit quoi : la première qui matche gagne.
- On ne déploie jamais sans avoir lu le `--check --diff`.
- DNSSEC hors périmètre : ne pas mettre sous gestion un serveur dont
  les zones sont signées.
