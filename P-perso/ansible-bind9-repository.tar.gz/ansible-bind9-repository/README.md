# Ansible BIND9 repository

Two roles are provided:

- `bind9_setup`: installs BIND9, creates the directory layout, and manages `/etc/bind/named.conf*`.
- `bind9_update_zones`: manages the primary zone files below `/var/cache/bind/primary/<view>/`.

Result on the managed host:

```text
/etc/bind/
├── named.conf
├── named.conf.local
├── named.conf.options
├── named.conf.logging
├── named.conf.views
└── named.conf.acl

/var/cache/bind/primary/
├── view1/
│   ├── zone1.com
│   └── zone2.com
└── view2/
    ├── zone1.com
    └── zone2.com
```

The example targets Debian/Ubuntu (`bind9` package and systemd service).

## Run

Edit `inventory/hosts.yml` and `group_vars/bind_servers.yml`, then:

```bash
ansible-playbook --syntax-check site.yml
ansible-playbook site.yml
```

Tags:

```bash
ansible-playbook site.yml --tags bind9_setup
ansible-playbook site.yml --tags bind9_zones
```
